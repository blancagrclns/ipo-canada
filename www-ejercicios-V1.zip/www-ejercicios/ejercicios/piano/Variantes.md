# Variantes

- El piano abarca más de una octava. 

- El usuario puede escoger el número de octavas del piano

- Se añaden controles para manipular el sonido emitido (volumen, filtros, retrasos, etc.)




